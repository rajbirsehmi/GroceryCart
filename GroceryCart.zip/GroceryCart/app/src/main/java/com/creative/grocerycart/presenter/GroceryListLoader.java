package com.creative.grocerycart.presenter;

import com.creative.grocerycart.adapter.GroceryAdapter;

public interface GroceryListLoader {
    void attachAdapter(GroceryAdapter groceryAdapter);
}
